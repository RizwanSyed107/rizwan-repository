/**
 * 
 */
package com.rizwan.nw.bo;


/**
 * The Class RouteRt.
 *
 * @author Syed
 */
public class RouteRt {
	
	/** The id. */
	private int id;
	
	/** The subnet. */
	private String subnet; // rtDestination;
	
	/** The protocol name. */
	private String protocolName;
	
	/** The next hop. */
	private String nextHop; // <to>
	
	/** The interface name. */
	private String interfaceName; // <via>
	
	/**
	 * Instantiates a new route rt.
	 */
	public RouteRt() {
		
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Gets the subnet.
	 *
	 * @return the subnet
	 */
	public String getSubnet() {
		return subnet;
	}
	
	/**
	 * Sets the subnet.
	 *
	 * @param subnet the new subnet
	 */
	public void setSubnet(String subnet) {
		this.subnet = subnet;
	}
	
	/**
	 * Gets the protocol name.
	 *
	 * @return the protocol name
	 */
	public String getProtocolName() {
		return protocolName;
	}
	
	/**
	 * Sets the protocol name.
	 *
	 * @param protocolName the new protocol name
	 */
	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}
	
	/**
	 * Gets the next hop.
	 *
	 * @return the next hop
	 */
	public String getNextHop() {
		return nextHop;
	}
	
	/**
	 * Sets the next hop.
	 *
	 * @param nextHop the new next hop
	 */
	public void setNextHop(String nextHop) {
		this.nextHop = nextHop;
	}
	
	/**
	 * Gets the interface name.
	 *
	 * @return the interface name
	 */
	public String getInterfaceName() {
		return interfaceName;
	}
	
	/**
	 * Sets the interface name.
	 *
	 * @param interfaceName the new interface name
	 */
	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return this.subnet + "-" + this.nextHop + "-" + this.interfaceName + "-" + this.protocolName;
	}
	
}
