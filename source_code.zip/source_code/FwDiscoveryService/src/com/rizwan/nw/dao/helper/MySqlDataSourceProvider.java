/**
 * 
 */
package com.rizwan.nw.dao.helper;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;


/**
 * The Class MySqlDataSourceHelper.
 *
 * @author Syed
 */
public class MySqlDataSourceProvider {
	
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(MySqlDataSourceProvider.class.getName());
	
	/**
	 * Gets the my SQL data source.
	 *
	 * @return the my SQL data source
	 */
	public static MysqlDataSource getMySQLDataSource() {

		Properties props = new Properties();

		String fileName = "routeinfo.properties";

		try (FileInputStream fis = new FileInputStream(fileName)) {
			props.load(fis);
		} catch (IOException ex) {
			LOG.log(Level.SEVERE, ex.getMessage(), ex);
		}

		MysqlDataSource ds = new MysqlDataSource();
		ds.setURL(props.getProperty("db.url"));
		ds.setUser(props.getProperty("db.username"));
		ds.setPassword(props.getProperty("db.password"));

		return ds;
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

		MysqlDataSource ds = getMySQLDataSource();

		String query = "SELECT VERSION()";

		try (Connection con = ds.getConnection();
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery()) {

			if (rs.next()) {

				String version = rs.getString(1);
				//System.out.println(version);
			}
		} catch (SQLException ex) {
			LOG.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}
}
