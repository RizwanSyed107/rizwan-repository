/**
 * 
 */
package com.rizwan.nw.dto;

/**
 * The Class FwDiscoveryDto.
 *
 * @author Syed
 */

public class FwDiscoveryDto {
	
	/** The host name. */
	private String hostName; // fw info
	
	/** The ip address. */
	private String ipAddress; // fw info
	
	/** The table name. */
	private String tableName;
	
	/** The subnet. */
	private String subnet;
	
	/** The next hop. */
	private String nextHop;
	
	/** The internface name. */
	private String internfaceName;
	
	/**
	 * Gets the host name.
	 *
	 * @return the host name
	 */
	public String getHostName() {
		return hostName;
	}
	
	/**
	 * Sets the host name.
	 *
	 * @param hostName the new host name
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	
	/**
	 * Gets the ip address.
	 *
	 * @return the ip address
	 */
	public String getIpAddress() {
		return ipAddress;
	}
	
	/**
	 * Sets the ip address.
	 *
	 * @param ipAddress the new ip address
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	
	/**
	 * Gets the table name.
	 *
	 * @return the table name
	 */
	public String getTableName() {
		return tableName;
	}
	
	/**
	 * Sets the table name.
	 *
	 * @param tableName the new table name
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	/**
	 * Gets the subnet.
	 *
	 * @return the subnet
	 */
	public String getSubnet() {
		return subnet;
	}
	
	/**
	 * Sets the subnet.
	 *
	 * @param subnet the new subnet
	 */
	public void setSubnet(String subnet) {
		this.subnet = subnet;
	}
	
	/**
	 * Gets the next hop.
	 *
	 * @return the next hop
	 */
	public String getNextHop() {
		return nextHop;
	}
	
	/**
	 * Sets the next hop.
	 *
	 * @param nextHop the new next hop
	 */
	public void setNextHop(String nextHop) {
		this.nextHop = nextHop;
	}
	
	/**
	 * Gets the internface name.
	 *
	 * @return the internface name
	 */
	public String getInternfaceName() {
		return internfaceName;
	}
	
	/**
	 * Sets the internface name.
	 *
	 * @param internfaceName the new internface name
	 */
	public void setInternfaceName(String internfaceName) {
		this.internfaceName = internfaceName;
	}
	
	
}
