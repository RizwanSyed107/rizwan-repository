create schema routeinfo;

use routeinfo;

create table FirewallInfo(
	ID int NOT NULL AUTO_INCREMENT,
	hostName varchar(255) NOT NULL,
	ipAddress varchar(20),
	PRIMARY KEY (ID)
);

create table RouteTable(
	ID int NOT NULL AUTO_INCREMENT,
	tableName varchar(255) NOT NULL,
	fwInfoId int,
	PRIMARY KEY (ID),
	CONSTRAINT FK_FwInfo FOREIGN KEY(fwInfoId) REFERENCES FirewallInfo(ID)
);

create table RouteRt(
	ID int NOT NULL AUTO_INCREMENT,
	subnet varchar(25) NOT NULL,
	protocolName varchar(20),
	nextHop varchar(20),
	interfaceName varchar(50),
	routeTableId int,
	PRIMARY KEY (ID),
	CONSTRAINT FK_RouteTable FOREIGN KEY(routeTableId) REFERENCES RouteTable(ID)
);