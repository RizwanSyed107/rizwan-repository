/**
 * 
 */
package com.rizwan.nw.bo;

import java.util.ArrayList;
import java.util.List;


/**
 * The Class RouteInformation.
 *
 * @author Syed
 */
public class RouteInformation {
	
	/** The firewall info. */
	FirewallInfo firewallInfo;
	
	/** The route tables. */
	List<RouteTable> routeTables;
	
	/**
	 * Instantiates a new route information.
	 */
	public RouteInformation() {
		routeTables = new ArrayList<RouteTable>(3);
	}

	/**
	 * Gets the firewall info.
	 *
	 * @return the firewall info
	 */
	public FirewallInfo getFirewallInfo() {
		return firewallInfo;
	}

	/**
	 * Sets the firewall info.
	 *
	 * @param firewallInfo the new firewall info
	 */
	public void setFirewallInfo(FirewallInfo firewallInfo) {
		this.firewallInfo = firewallInfo;
	}

	/**
	 * Gets the route tables.
	 *
	 * @return the route tables
	 */
	public List<RouteTable> getRouteTables() {
		return routeTables;
	}

	/**
	 * Sets the route tables.
	 *
	 * @param routeTables the new route tables
	 */
	public void setRouteTables(List<RouteTable> routeTables) {
		this.routeTables = routeTables;
	}
	
	/**
	 * Adds the route table.
	 *
	 * @param routeTable the route table
	 */
	public void addRouteTable(RouteTable routeTable) {
		this.routeTables.add(routeTable);
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return this.firewallInfo + "\n" + this.routeTables;
	}

}
