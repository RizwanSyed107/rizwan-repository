/**
 * 
 */
package com.rizwan.nw.res;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.rizwan.nw.dto.FwDiscoveryDto;
import com.rizwan.nw.dto.RouteDiscoveryResponse;
import com.rizwan.nw.service.FwDiscoveryService;


/**
 * The Class FwDiscoveryResource.
 *
 * @author Syed
 */
@Path("/fwdiscovery")
public class FwDiscoveryResource {

    /**
     * Gets the route info.
     *
     * @param ip the ip
     * @return the route info
     */
    // This method is called if JSON is requested
    @GET
    @Path("{ip}")
    @Produces({MediaType.APPLICATION_JSON})
    public RouteDiscoveryResponse getRouteInfo(@PathParam("ip") String ip) {
    	RouteDiscoveryResponse response = null;
    	try {
    		response = new FwDiscoveryService().getRouteInfo(ip);		
    	} catch (Exception e) {
    		e.printStackTrace();
    		response = new RouteDiscoveryResponse();
    		response.setValid(false);
    		response.setError("Unknown service error...");
    	}

    	return response;
    }
    
    @GET
    @Path("/defaultroute")
    @Produces({MediaType.APPLICATION_JSON})
    public RouteDiscoveryResponse getRouteInfo() {
    	RouteDiscoveryResponse response = null;
    	try {
    		response = new FwDiscoveryService().getRouteInfo("0.0.0.1");		
    	} catch (Exception e) {
    		e.printStackTrace();
    		response = new RouteDiscoveryResponse();
    		response.setValid(false);
    		response.setError("Unknown service error...");
    	}

    	return response;
    }
    
}
