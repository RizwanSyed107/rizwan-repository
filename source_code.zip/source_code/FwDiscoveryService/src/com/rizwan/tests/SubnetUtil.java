/**
 * 
 */
package com.rizwan.tests;

import org.apache.commons.net.util.SubnetUtils;


/**
 * The Class SubnetUtil.
 *
 * @author Syed
 */
public class SubnetUtil {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubnetUtils utils = new SubnetUtils("10.1.2.50/32");
		System.out.println("cnt:"+utils.getInfo().getAddressCountLong());
		System.out.println("Address:"+utils.getInfo().getAddress());
		System.out.println("NW Address:"+utils.getInfo().getNetworkAddress());
		System.out.println("Netmask:"+utils.getInfo().getNetmask());
		System.out.println("Low Addr:"+utils.getInfo().getLowAddress());
		System.out.println("High Addr:"+utils.getInfo().getHighAddress());
		
		System.out.println("Broadcast addr:"+utils.getInfo().getBroadcastAddress());
		
		System.out.println("is in range:"+utils.getInfo().isInRange("10.1.2.54"));
		
	}

}
