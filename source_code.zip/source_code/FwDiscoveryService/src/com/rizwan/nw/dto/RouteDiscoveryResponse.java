/**
 * 
 */
package com.rizwan.nw.dto;

import java.util.List;


/**
 * The Class RouteDiscoveryResponse.
 *
 * @author Syed
 */
public class RouteDiscoveryResponse {
	
	/** The valid. */
	private boolean valid;
	
	/** The error. */
	String error;
	
	/** The discovery dtos. */
	List<FwDiscoveryDto> discoveryDtos;
	
	/**
	 * Checks if is valid.
	 *
	 * @return true, if is valid
	 */
	public boolean isValid() {
		return valid;
	}
	
	/**
	 * Sets the valid.
	 *
	 * @param valid the new valid
	 */
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	
	/**
	 * Gets the error.
	 *
	 * @return the error
	 */
	public String getError() {
		return error;
	}
	
	/**
	 * Sets the error.
	 *
	 * @param error the new error
	 */
	public void setError(String error) {
		this.error = error;
	}
	
	/**
	 * Gets the discovery dtos.
	 *
	 * @return the discovery dtos
	 */
	public List<FwDiscoveryDto> getDiscoveryDtos() {
		return discoveryDtos;
	}
	
	/**
	 * Sets the discovery dtos.
	 *
	 * @param discoveryDtos the new discovery dtos
	 */
	public void setDiscoveryDtos(List<FwDiscoveryDto> discoveryDtos) {
		this.discoveryDtos = discoveryDtos;
	}

}
