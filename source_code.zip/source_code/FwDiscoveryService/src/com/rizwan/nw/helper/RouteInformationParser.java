/**
 * 
 */
package com.rizwan.nw.helper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.rizwan.nw.bo.FirewallInfo;
import com.rizwan.nw.bo.RouteInformation;
import com.rizwan.nw.bo.RouteRt;
import com.rizwan.nw.bo.RouteTable;


/**
 * The Class RouteInformationParser.
 *
 * @author Syed
 */
public class RouteInformationParser {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(RouteInformationParser.class.toString());	
	
	/**
	 * Parses the route resource.
	 *
	 * @param resFile the res file
	 * @return the route information
	 */
	public static RouteInformation parseRouteResource(File resFile) {

		String xmlFileName = resFile.getName();
		RouteInformation routeInformation = null;
		try {
			routeInformation = new RouteInformation();

			FirewallInfo firewallInfo = new FirewallInfo();
			firewallInfo.setHostName( xmlFileName.substring(0, xmlFileName.indexOf("---") ) );
			firewallInfo.setIpAddress( xmlFileName.substring(xmlFileName.indexOf("---") + 3, xmlFileName.length()-4 ) );
			
			routeInformation.setFirewallInfo(firewallInfo);

			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();

			Document doc = dBuilder.parse(resFile);

			NodeList routeTableNodes = doc.getElementsByTagName("route-table");
			//System.out.println("routeInfoNodes :" + routeTableNodes);

			if (routeTableNodes != null && routeTableNodes.getLength() > 0) {

				for (int count = 0; count < routeTableNodes.getLength(); count++) {
					Node routeTableNode = routeTableNodes.item(count);
					//System.out.println("routeTableNode::"+routeTableNode.getNodeName());

					RouteTable routeTable = new RouteTable();
					//routeTable.setFirewallInfo(firewallInfo);

					NodeList routeTableChildren = routeTableNode.getChildNodes();

					for (int icnt = 0; icnt < routeTableChildren.getLength(); icnt++) {

						if( "table-name".equalsIgnoreCase(routeTableChildren.item(icnt).getNodeName() )) {

							routeTable.setTableName(routeTableChildren.item(icnt).getTextContent());

						} else if( "rt".equalsIgnoreCase(routeTableChildren.item(icnt).getNodeName() )) {

							RouteRt routeRt = getRtInfo(routeTableChildren.item(icnt));
							routeTable.addRouteRt(routeRt);

						}

					}

					// End of RouteTable
					routeInformation.addRouteTable(routeTable);
				}

			}



		} catch (Exception e) {
			//System.out.println(e.getMessage());
			e.printStackTrace();
		}

		return routeInformation;
	}

	/**
	 * Gets the rt info.
	 *
	 * @param rtNode the rt node
	 * @return the rt info
	 */
	private static RouteRt getRtInfo(Node rtNode) {

		if(rtNode == null) {
			return null;
		}
		RouteRt rt = null;

		if ( rtNode.getNodeType() == Node.ELEMENT_NODE) {

			rt = new RouteRt();

			Element eElement = (Element) rtNode;

			rt.setSubnet(eElement.getElementsByTagName("rt-destination").item(0).getTextContent());

			rt.setProtocolName(eElement.getElementsByTagName("protocol-name").item(0).getTextContent());

			if(eElement.getElementsByTagName("to") != null && eElement.getElementsByTagName("to").getLength()>0) {
				rt.setNextHop(eElement.getElementsByTagName("to").item(0).getTextContent());	
			}

			if(eElement.getElementsByTagName("via") != null && eElement.getElementsByTagName("via").getLength()>0) {
				rt.setInterfaceName(eElement.getElementsByTagName("via").item(0).getTextContent());
			}

		}
		return rt;
	}

}
