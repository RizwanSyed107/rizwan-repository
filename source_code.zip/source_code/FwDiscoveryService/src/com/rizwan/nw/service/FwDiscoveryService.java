/**
 * 
 */
package com.rizwan.nw.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.net.util.SubnetUtils;

import com.rizwan.nw.dao.RouteInformationDao;
import com.rizwan.nw.dto.FwDiscoveryDto;
import com.rizwan.nw.dto.RouteDiscoveryResponse;
import com.rizwan.tests.SubnetUtil;

/**
 * The Class FwDiscoveryService.
 *
 * @author Syed
 */
public class FwDiscoveryService {
	
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(FwDiscoveryService.class.toString());
	
	/**
	 * Gets the route info.
	 *
	 * @param ipAddress the ip address
	 * @return the route info
	 */
	public RouteDiscoveryResponse getRouteInfo(String ipAddress) {
		RouteDiscoveryResponse discoveryResponse = new RouteDiscoveryResponse();
		
		RouteInformationDao dao = new RouteInformationDao();
		try {
			discoveryResponse.setDiscoveryDtos( resolveSubnets(dao.getSubnets(ipAddress), ipAddress) );
		} catch (SQLException e) {
			// LOG it
			e.printStackTrace();
			discoveryResponse.setValid(false);
		}  catch (Exception e) {
			// LOG it
			e.printStackTrace();
			discoveryResponse.setValid(false);
		}
		discoveryResponse.setValid(true);
		
		return discoveryResponse;
	}

	/**
	 * Resolve subnets.
	 *
	 * @param subnets the subnets
	 * @param ipAddress the ip address
	 * @return the list
	 */
	private List<FwDiscoveryDto> resolveSubnets(List<FwDiscoveryDto> subnets, String ipAddress) {
		
		List<FwDiscoveryDto> finalDiscoveryDtos = new ArrayList<FwDiscoveryDto>(3);
		
		for (FwDiscoveryDto fwDiscoveryDto : subnets) {
			SubnetUtils utils = new SubnetUtils(fwDiscoveryDto.getSubnet());
//			System.out.println("cnt:"+utils.getInfo().getAddressCountLong());
//			System.out.println("Low Addr:"+utils.getInfo().getLowAddress());
//			System.out.println("High Addr:"+utils.getInfo().getHighAddress());
			boolean isInRange = utils.getInfo().isInRange(ipAddress);
//			System.out.println("is in range:"+isInRange);
			if(isInRange) {
				finalDiscoveryDtos.add(fwDiscoveryDto);
			} else if(utils.getInfo().getAddressCountLong() == 0 && utils.getInfo().getAddress().equals(ipAddress)) {
				finalDiscoveryDtos.add(fwDiscoveryDto);
			}
		}
		return finalDiscoveryDtos;
		
	}

}
