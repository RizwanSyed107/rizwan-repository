/**
 * 
 */
package com.rizwan.tests;

import com.rizwan.nw.dto.RouteDiscoveryResponse;
import com.rizwan.nw.helper.RouteInfoStorageHandler;
import com.rizwan.nw.service.FwDiscoveryService;


/**
 * The Class TestRouteInfoParser.
 *
 * @author Syed
 */
public class InvokeRouteInfoStorage {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		new RouteInfoStorageHandler().processRouteInfoResources("route_xml_res");
		
		//RouteDiscoveryResponse response = new FwDiscoveryService().getRouteInfo("10.66.120.55");		
		//System.out.println("response:"+response);
	}
}
