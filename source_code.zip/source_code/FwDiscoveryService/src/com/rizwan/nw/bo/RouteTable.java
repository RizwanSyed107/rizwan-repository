/**
 * 
 */
package com.rizwan.nw.bo;

import java.util.ArrayList;
import java.util.List;


/**
 * The Class RouteTable.
 *
 * @author Syed
 */
public class RouteTable {
	//private FirewallInfo firewallInfo;
	
	/** The table name. */
	private String tableName;
	
	/** The rt list. */
	private List<RouteRt> rtList;
	
	/**
	 * Instantiates a new route table.
	 */
	public RouteTable() {
		rtList = new ArrayList<RouteRt>(3);
	}
	
	/**
	 * Instantiates a new route table.
	 *
	 * @param tableName the table name
	 */
	public RouteTable(String tableName) {
		this.tableName = tableName;
		rtList = new ArrayList<RouteRt>(3);
	}

//	public FirewallInfo getFirewallInfo() {
//		return firewallInfo;
//	}
//
//	public void setFirewallInfo(FirewallInfo firewallInfo) {
//		this.firewallInfo = firewallInfo;
//	}

	/**
 * Gets the table name.
 *
 * @return the table name
 */
public String getTableName() {
		return tableName;
	}

	/**
	 * Sets the table name.
	 *
	 * @param tableName the new table name
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * Gets the rt list.
	 *
	 * @return the rt list
	 */
	public List<RouteRt> getRtList() {
		return rtList;
	}

	/**
	 * Sets the rt list.
	 *
	 * @param rtList the new rt list
	 */
	public void setRtList(List<RouteRt> rtList) {
		this.rtList = rtList;
	}
	
	/**
	 * Adds the route rt.
	 *
	 * @param rt the rt
	 */
	public void addRouteRt(RouteRt rt) {
		this.rtList.add(rt);
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "\n tableName: "+this.tableName + " \n " + this.rtList;
	}
	
	
}
