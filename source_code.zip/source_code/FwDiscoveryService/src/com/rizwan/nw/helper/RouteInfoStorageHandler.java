/**
 * 
 */
package com.rizwan.nw.helper;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

import com.rizwan.nw.bo.RouteInformation;
import com.rizwan.nw.dao.RouteInformationDao;


/**
 * The Class RouteInfoStorageHandler.
 *
 * @author Syed
 */
public class RouteInfoStorageHandler {
	
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(RouteInfoStorageHandler.class.toString());
	
	/**
	 * Parses the route resources.
	 *
	 * @param path the path
	 */
	
	public void processRouteInfoResources(String path) {
		File resPath = new File(path);
		if(resPath.exists()) {
			File[] routeInfoResFiles = resPath.listFiles();

			for (File resFile : routeInfoResFiles) {
				RouteInformation routeInformation = parseRouteResource(resFile);
				System.out.println("************* routeInformation ****************");
				System.out.println(routeInformation);
				
				storeRouteInformation(routeInformation);
			}
		}
	}

	/**
	 * Store route information.
	 *
	 * @param routeInformation the route information
	 */
	private void storeRouteInformation(RouteInformation routeInformation) {
		// All dB activity
		System.out.println("Storing parsed route information...");
				
		RouteInformationDao dao = new RouteInformationDao();
		try {
			dao.storeRouteResInfo(routeInformation);
		} catch (SQLException e) {
			// TODO LOG this
			e.printStackTrace();
		} catch (Exception e) {
			// TODO LOG this
			e.printStackTrace();
		}
	}

	/**
	 * Parses the route resource.
	 *
	 * @param resFile the res file
	 * @return the route information
	 */
	private static RouteInformation parseRouteResource(File resFile) {
		return RouteInformationParser.parseRouteResource(resFile);
	}


}
