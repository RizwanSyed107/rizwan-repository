/**
 * 
 */
package com.rizwan.nw.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import com.rizwan.nw.bo.FirewallInfo;
import com.rizwan.nw.bo.RouteInformation;
import com.rizwan.nw.bo.RouteRt;
import com.rizwan.nw.bo.RouteTable;
import com.rizwan.nw.dao.helper.MySqlDataSourceProvider;
import com.rizwan.nw.dto.FwDiscoveryDto;


/**
 * The Class RouteInformationDao.
 *
 * @author Syed
 */
public class RouteInformationDao {
	
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(RouteInformationDao.class.toString());

	//	public Connection getConnection() {
	//		String url = "jdbc:mysql://localhost:3306/routeinfo?useSSL=false";
	//        String user = "root";
	//        String password = "root";
	//
	//        Connection con = null;
	//		try {
	//			con = DriverManager.getConnection(url, user, password);
	//		} catch (SQLException e) {
	//			// TODO: LOG it
	//			e.printStackTrace();
	//		}
	//        return con;
	//	}

	/**
	 * Gets the connection.
	 *
	 * @return the connection
	 * @throws SQLException the SQL exception
	 */
	public Connection getConnection() throws SQLException {
		return MySqlDataSourceProvider.getMySQLDataSource().getConnection();
	}

	/**
	 * Store route res info.
	 *
	 * @param routeInformation the route information
	 * @return true, if successful
	 * @throws SQLException the SQL exception
	 */
	public boolean storeRouteResInfo(RouteInformation routeInformation) throws SQLException {
		boolean isStored = false;
		Connection connection = null;
		try {
			connection = getConnection();
			boolean isFwUpdated = insertFwInfo(routeInformation.getFirewallInfo(), connection);

			if(!isFwUpdated) {
				System.out.println("FW info ["+ routeInformation.getFirewallInfo() +"] not updated, returning...");
				// LOG some error
				return false;
			}

			int fwInfoId = getFwInfoId(routeInformation.getFirewallInfo(), connection);

			if(fwInfoId > 0) {
				isStored = updateRouteTables(routeInformation.getRouteTables(), fwInfoId, connection);	
			} else {
				System.out.println("FW info ["+ routeInformation.getFirewallInfo() +"] id not retrieved, returning...");
				// LOG some error
				return false;
			}

		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			if(connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				connection = null;
			}
		}
		return isStored;
	}

	/**
	 * Update route tables.
	 *
	 * @param routeTables the route tables
	 * @param fwInfoId the fw info id
	 * @param connection the connection
	 * @return true, if successful
	 */
	private boolean updateRouteTables(List<RouteTable> routeTables, int fwInfoId, Connection connection) {
		boolean isUpdated = true;

		if(routeTables == null || routeTables.size() == 0) {
			System.out.println("No data to update");
			return false;
		}

		int routeTableUpdtCnt = 0;
		for (RouteTable routeTable : routeTables) {
			boolean routeTableUpdated = insertRouteTable(routeTable, fwInfoId, connection);
			if(routeTableUpdated) {

				int routeTableId = getRouteTableId(routeTable, connection);
				if(routeTableId > 0) {
					int rtUpdateCnt = 0;
					for (RouteRt rt : routeTable.getRtList()) {
						if(insertRouteRt(rt, routeTableId, connection)) {
							rtUpdateCnt++;
						}
					}
					System.out.println("RouteRts updated:"+rtUpdateCnt);
					routeTableUpdtCnt++;
				} else {
					System.out.println("Invalid routetable id fetched:"+routeTable);
					break;
				}

			} else {
				isUpdated = false;
				System.out.println("Something went wrong,RouteTables not udpated.. ");
				break;
			}
		}
		System.out.println("RouteTables updated:"+routeTableUpdtCnt);
		return isUpdated;
	}

	/**
	 * Insert fw info.
	 *
	 * @param firewallInfo the firewall info
	 * @param connection the connection
	 * @return true, if successful
	 */
	private boolean insertFwInfo(FirewallInfo firewallInfo, Connection connection) {
		boolean isUpdated = false;
		String query = "INSERT INTO FirewallInfo(hostName, ipAddress) VALUES (?, ?)";
		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(query);

			pst.setString(1, firewallInfo.getHostName());
			pst.setString(2, firewallInfo.getIpAddress());
			int updateCnt = pst.executeUpdate();

			if(updateCnt > 0) {
				isUpdated = true;
				System.out.println("FW Info with hostname ["+ firewallInfo.getHostName() +"] Updated successfully..");
			} else {
				System.err.println("FW Info with hostname ["+ firewallInfo.getHostName() +"] Not Updated ..");
			}


		} catch (SQLException e) {
			// TODO LOG it
			e.printStackTrace();
		} finally {
			if(pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return isUpdated;
	}

	/**
	 * Insert route table.
	 *
	 * @param routeTable the route table
	 * @param fwInfoId the fw info id
	 * @param connection the connection
	 * @return true, if successful
	 */
	private boolean insertRouteTable(RouteTable routeTable, int fwInfoId, Connection connection) {
		boolean isUpdated = false;

		System.out.println("Inserting RouteTable with fwinfoid:"+fwInfoId);
		System.out.println("tablename:::::::"+routeTable.getTableName());

		String query = "INSERT INTO RouteTable(tableName, fwInfoId) VALUES (?, ?) ";
		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(query);

			pst.setString(1, routeTable.getTableName());
			pst.setInt(2, fwInfoId);
			int updateCnt = pst.executeUpdate();

			if(updateCnt > 0) {
				isUpdated = true;
				System.out.println("Route Table with table name ["+ routeTable.getTableName() +"] Updated successfully..");
			} else {
				System.err.println("Route Table with table name ["+ routeTable.getTableName() +"] Not Updated ..");
			}

		} catch (SQLException e) {
			// TODO LOG it
			e.printStackTrace();
		} finally {
			if(pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return isUpdated;
	}

	/**
	 * Insert route rt.
	 *
	 * @param routeRt the route rt
	 * @param routeTableId the route table id
	 * @param connection the connection
	 * @return true, if successful
	 */
	private boolean insertRouteRt(RouteRt routeRt, int routeTableId, Connection connection) {
		boolean isUpdated = false;

		System.out.println("Inserting RouteRt with routetableid:"+routeTableId);
		System.out.println(routeRt);

		String query = "INSERT INTO RouteRt(subnet, protocolName, nextHop, interfaceName, routeTableId) VALUES (?, ?, ?, ?, ?) ";
		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(query);

			pst.setString(1, routeRt.getSubnet());
			pst.setString(2, routeRt.getProtocolName());
			pst.setString(3, routeRt.getNextHop());
			pst.setString(4, routeRt.getInterfaceName());
			pst.setInt(5, routeTableId);
			int updateCnt = pst.executeUpdate();

			if(updateCnt > 0) {
				isUpdated = true;
				System.out.println("Route Rt with subnet ["+ routeRt.getSubnet() +"] Updated successfully..");
			} else {
				System.err.println("Route Rt with subnet ["+ routeRt.getSubnet() +"] Not Updated ..");
			}


		} catch (SQLException e) {
			// TODO LOG it
			e.printStackTrace();
		} finally {
			if(pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return isUpdated;
	}

	/**
	 * Gets the fw info id.
	 *
	 * @param firewallInfo the firewall info
	 * @param connection the connection
	 * @return the fw info id
	 */
	private int getFwInfoId(FirewallInfo firewallInfo, Connection connection) {
		int fwId = 0;
		String query = "SELECT ID FROM FirewallInfo fw WHERE fw.hostName=? ";
		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(query);

			pst.setString(1, firewallInfo.getHostName());
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				fwId = rs.getInt(1);
			}

		} catch (SQLException e) {
			// TODO LOG it
			e.printStackTrace();
		} finally {
			if(pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return fwId;
	}

	/**
	 * Gets the route table id.
	 *
	 * @param routeTable the route table
	 * @param connection the connection
	 * @return the route table id
	 */
	private int getRouteTableId(RouteTable routeTable, Connection connection) {
		int rtTableId = 0;
		String query = "SELECT ID FROM RouteTable rt WHERE rt.tableName=? ";
		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(query);

			pst.setString(1, routeTable.getTableName());
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				rtTableId = rs.getInt(1);
			}

		} catch (SQLException e) {
			// TODO LOG it
			e.printStackTrace();
		} finally {
			if(pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return rtTableId;
	}

	/**
	 * Gets the subnets.
	 *
	 * @param inputIpAddress the input ip address
	 * @return the subnets
	 * @throws SQLException the SQL exception
	 */
	public List<FwDiscoveryDto> getSubnets(String inputIpAddress) throws SQLException {

		Connection connection = getConnection();

		List<FwDiscoveryDto> discoveryDtos = new ArrayList<FwDiscoveryDto>(3);
		System.out.println("inputIpAddress::"+inputIpAddress);
		String ipAddrArr[] = inputIpAddress.split(Pattern.quote("."));
		System.out.println("len ipAddrArr::"+ipAddrArr.length);
		String ipStartWith = ipAddrArr[0] + "." + ipAddrArr[1] + ".";

		String query = "SELECT DISTINCT fw.hostName, fw.ipAddress, rtbl.tableName, rt.subnet, rt.nextHop, rt.interfaceName "
				+ " FROM firewallinfo fw INNER JOIN routetable rtbl INNER JOIN routert rt "
				+ " ON fw.ID=rtbl.fwInfoId AND rt.routeTableId=rtbl.ID AND rt.subnet LIKE ? ";

		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(query);

			pst.setString(1, ipStartWith + "%");
			ResultSet rs = pst.executeQuery();
			FwDiscoveryDto discoveryDto = null;
			while(rs.next()) {
				discoveryDto = new FwDiscoveryDto();
				discoveryDto.setHostName(rs.getString(1));
				discoveryDto.setIpAddress(rs.getString(2));
				discoveryDto.setTableName(rs.getString(3));
				discoveryDto.setSubnet(rs.getString(4));
				discoveryDto.setNextHop(rs.getString(5));
				discoveryDto.setInternfaceName(rs.getString(6));

				discoveryDtos.add(discoveryDto);
			}

		} catch (SQLException e) {
			// TODO LOG it
			e.printStackTrace();
		} catch (Exception e) {
			// TODO LOG it
			e.printStackTrace();
		} finally {
			if(pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				connection = null;
			}
		}

		return discoveryDtos;

	}

}
